﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class Teamentity
    {
        public int TEAM_ID { get; set; }
        public string TEAM_NAME { get; set; }
        public string TEAM_CITY { get; set; }

    }
}
