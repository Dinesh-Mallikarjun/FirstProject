﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class Doctor
    {

        public int DoctoreId { set; get; }

        public string DoctorName { set; get; }

        public int Salary { set; get; }

    }
}