﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoctorProject.Models
{
    public class DoctorModel
    {
        public int DoctoreId { set; get; }

        public string DoctorName { set; get; }

        public int Salary { set; get; }

    }
}