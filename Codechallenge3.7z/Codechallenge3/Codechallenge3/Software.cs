﻿namespace capability
{
    public class Software
    {
        private string licencenumber;
        internal string name;
        internal double cost;

        public int Id { get; internal set; }
        internal string Licencenumber { get => licencenumber; set => licencenumber = value; }
    }
}