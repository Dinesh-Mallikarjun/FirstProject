﻿namespace capability
{
    public class Software
    {
        internal int cost;
        internal object licencenumber;
        internal string name;



        public int Id { get; internal set; }
    }
}